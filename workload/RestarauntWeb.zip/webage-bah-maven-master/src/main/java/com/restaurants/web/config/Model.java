package com.restaurants.web.config;

import com.restaurants.web.data.Restaurant;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.client.RestTemplate;

@ControllerAdvice
public class Model {


}
