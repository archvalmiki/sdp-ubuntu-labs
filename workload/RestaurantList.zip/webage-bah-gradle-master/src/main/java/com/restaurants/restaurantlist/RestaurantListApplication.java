package com.restaurants.restaurantlist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantListApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantListApplication.class, args);
	}

}
